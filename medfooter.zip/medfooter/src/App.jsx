import React from 'react';
import Footer from './components/Footer';

function App() {
  return (
    <>
      <main>
        {/* Your page content goes here */}
      </main>
      <Footer />
    </>
  );
}

export default App;
