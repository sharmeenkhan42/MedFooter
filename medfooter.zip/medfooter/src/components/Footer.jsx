import React from 'react';

function Footer() {
  return (
    <footer
      className="text-light pt-5 pb-3"
      style={{
        backgroundColor: '#2e3572',
        width: '100%',
        fontFamily: 'Arial, sans-serif',
        position: 'relative',
      }}
    >
      <div className="container">
        <div className="row pb-4">
          <div className="col-md-4 mb-4 mb-md-0">
            <h2 style={{ fontFamily: 'Georgia, serif', letterSpacing: '2px' }}>MEDDICAL</h2>
            <p className="mt-3">
              Leading the Way in Medical Excellence,<br />
              Trusted Care.
            </p>
          </div>
          <div className="col-md-2 mb-4 mb-md-0">
            <h6 className="fw-bold mb-3">Important Links</h6>
            <ul className="list-unstyled">
              <li><a href="#" className="text-light text-decoration-none d-block mb-2">Appointment</a></li>
              <li><a href="#" className="text-light text-decoration-none d-block mb-2">Doctors</a></li>
              <li><a href="#" className="text-light text-decoration-none d-block mb-2">Services</a></li>
              <li><a href="#" className="text-light text-decoration-none d-block">About Us</a></li>
            </ul>
          </div>
          <div className="col-md-3 mb-4 mb-md-0">
            <h6 className="fw-bold mb-3">Contact Us</h6>
            <ul className="list-unstyled">
              <li className="mb-2">Call: (237) 681-812-255</li>
              <li className="mb-2">Email: fildineeso@gmail.com</li>
              <li className="mb-2">Address: 0123 Some place</li>
              <li>Some country</li>
            </ul>
          </div>
          <div className="col-md-3">
            <h6 className="fw-bold mb-3">Newsletter</h6>
            <form className="d-flex">
              <input
                type="email"
                className="form-control me-2 rounded"
                placeholder="Enter your email address"
              />
              <button className="btn btn-light rounded" type="submit">
                <i className="bi bi-send"></i>
              </button>
            </form>
          </div>
        </div>
        <hr className="border-secondary" />
        <div className="row align-items-center">
          <div className="col-md-8">
            <p className="mb-0 text-white-50">
              &copy; 2021 Hospital's name All Rights Reserved by PNTEC-LTD
            </p>
          </div>
          <div className="col-md-4 text-md-end mt-3 mt-md-0">
            <a href="#" className="text-light me-4"><i className="bi bi-linkedin fs-5"></i></a>
            <a href="#" className="text-light me-4"><i className="bi bi-facebook fs-5"></i></a>
            <a href="#" className="text-light"><i className="bi bi-instagram fs-5"></i></a>
          </div>
        </div>
      </div>

      <div
        style={{
          position: 'absolute',
          inset: 0,
          border: '2px solid #b48ef2',
          borderRadius: '2px',
          pointerEvents: 'none',
          boxSizing: 'border-box',
        }}
      />
    </footer>
  );
}

export default Footer;
